import "./style.css";
import heroImg from "./assets/hero.png";
import qrImg from "./assets/qr.png";
import card from "./assets/qards/card.png";
import card1 from "./assets/qards/card1.png";
import card2 from "./assets/qards/card2.png";
import card3 from "./assets/qards/card3.png";
import screenImg from "./assets/screen.png";
import man from "./assets/qards/man.png";
import woman from "./assets/qards/woman.png";
import slide2 from "./assets/slides/slide2.png";
import slide3 from "./assets/slides/slide3.png";
import slide4 from "./assets/slides/slide4.png";
import slide5 from "./assets/slides/slide5.png";
import slide6 from "./assets/slides/slide6.png";
import slide7 from "./assets/slides/slide7.png";
import slide8 from "./assets/slides/slide8.png";
import slide9 from "./assets/slides/slide9.png";
import news1 from "./assets/news1.png";
import news2 from "./assets/news2.png";
import news3 from "./assets/news3.png";

const slidesData = [
  {
    title: "Evoca Travel Card",
    desc: "Այս քարտն իր բազմաթիվ առավելություններով կդառնա քո ճամփորդական անբաժան ընկերը",
    img: heroImg,
    bg: "#dadada",
  },
  {
    title: "Օնլայն ավանդ EvocaTOUCH հավելվածով",
    desc: "Դի'ր ավանդ Evocabank-ում` բարձր, շա'տ բարձր տոկոսներով:",
    img: slide2,
    bg: "#ffdcfc",
  },
  {
    title: "Visa Vision",
    desc: "Ձեռք բեր Visa Vision քարտ քո նախընտրած գույնով, դիզայնով ու ոճով և օգտվիր բազմաթիվ առավելություններից",
    img: slide3,
    bg: "#28292d",
  },
  {
    title: "Evoca պարտատոմսեր",
    desc: "Evocabank-ը կթողարկի դրամով, դոլարով ու եվրոյով պարտատոմսեր՝ մինչև 10.5% եկամտաբերությամբ",
    img: slide4,
    bg: "#e2e1ec",
  },
  {
    title: "UnionPay Gold",
    desc: "Ամբողջ աշխարհում քո արագ և հարմար վճարումների ուղեկիցը",
    img: slide5,
    bg: "#b59937",
  },
  {
    title: "Evoca Աշխատավարձային նախագիծ",
    desc: "Բեր աշխատավարձդ Evoca: Տար շատ ավելին...",
    img: slide6,
    bg: "#6539aa",
  },
  {
    title: "Կարճ հեռախոսահամար` 8444",
    desc: "Բարի գալուստ, Evocabank: Մենք սպասում ենք Ձեր զանգին...",
    img: slide7,
    bg: "#000000",
  },
  {
    title: "Հիփոթեքային վարկեր Evocabank-ում` ամենահարմար պայմաններով",
    desc: "Ձեռք բեր քո երազանքի բնակարանը` ցածր տոկոսադրույքով:",
    img: slide8,
    bg: "#e4defc",
  },
  {
    title: "Evoca Թվային քարտեր",
    desc: "Ակտիվացրու թվային քարտը հենց հավելվածում",
    img: slide9,
    bg: "#28282c",
  },
];

const newsData = [
  {
    tag: "Պրոդուկտներ",
    color: "#e600e6",
    title: "Սև Ուրբաթ՝ 20% cashback-ով և գեղեցիկ Evoca Mastercard քարտերով",
    date: "19.11.2026",
    img: news1,
  },
  {
    tag: "Բանկային",
    color: "#6a0dd9",
    title: "Evocabank-ը թողարկել է պարտատոմսեր՝ դրամով, դոլարով և եվրոյով",
    date: "09.11.2026",
    img: news2,
  },
  {
    tag: "Կենսաոճ",
    color: "#a6f500",
    title: "Evocabank-ը՝ TOON EXPO. INVEST 2026 Vol. 2-ին",
    date: "06.11.2026",
    img: news3,
  },
];

const newsCards = newsData
  .map(
    (n) => `
    <a href="#" class="news-card">
      <img class="news-img" src="${n.img}" alt="">
      <div class="news-body">
        <span class="news-tag" style="border-left-color:${n.color}">${n.tag}</span>
        <h3>${n.title}</h3>
        <span class="news-date">${n.date}</span>
      </div>
    </a>`
  )
  .join("");

let current = 0;

document.querySelector("#app").innerHTML = `
  <div class="topbar">
    <ul class="topbar-left">
      <li class="active"><a href="#">Անհատ</a></li>
      <li><a href="#">Բիզնես</a></li>
      <li><a href="#">Ակնթարթային վճարումներ</a></li>
      <li><a href="#">Մեր մասին</a></li>
      <li><a href="#">Նորություններ</a></li>
      <li><a href="#">Բլոգ</a></li>
      <li><a href="#">Կարիերա</a></li>
    </ul>
    <div class="topbar-right">
      <a href="#" class="purple">Առցանց հայտեր <i class="nish"></i></a>
      <a href="#" class="purple">Հետադարձ կապ <i class="nish"></i></a>
      <div class="icons">
        <svg width="14" height="16" viewBox="0 0 24 24"><path fill="#222" d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>
        <svg width="16" height="16" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#222"/><text x="12" y="17" text-anchor="middle" font-size="14" font-weight="700" fill="#fff">?</text></svg>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#222" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2c3 3 3 17 0 20M12 2c-3 3-3 17 0 20"/></svg>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#222" stroke-width="2.5"><circle cx="10" cy="10" r="7"/><path d="M15 15l7 7"/></svg>
      </div>
      <svg class="tox" width="20" height="16" viewBox="0 0 20 16" stroke="#222" stroke-width="2"><path d="M0 2h20M6 8h14M0 14h20"/></svg>
    </div>
  </div>

  <header class="header">
    <a href="#" class="logo">e<span>v</span>oca</a>
    <nav class="nav">
      <a href="#">Վարկեր</a>
      <a href="#">Քարտեր</a>
      <a href="#">Ավանդներ</a>
      <a href="#">Հաշիվներ</a>
      <a href="#">Փոխանցումներ</a>
      <a href="#">Արժեթղթեր</a>
      <a href="#">EvocaSALARY</a>
      <a href="#">EvocaTOUCH</a>
    </nav>
    <a href="#" class="button button-small">EvocaONLINE</a>
  </header>

  <section class="hero" id="heroSection">
    <div class="hero-text">
      <h1 id="heroTitle"></h1>
      <p id="heroDesc"></p>
      <a href="#" class="button button-big">Իմանալ ավելին</a>
    </div>

    <img class="hero-img" id="heroImg" src="" alt="">

    <div class="slider">
      <button class="arrow" id="prev">
        <svg width="26" height="14" viewBox="0 0 26 14" fill="none" stroke="#6a0dd9" stroke-width="2"><path d="M26 7H1M7 1L1 7l6 6"/></svg>
      </button>
      <div class="dots" id="dotsContainer"></div>
      <button class="arrow" id="next">
        <svg width="26" height="14" viewBox="0 0 26 14" fill="none" stroke="#6a0dd9" stroke-width="2"><path d="M0 7h25M19 1l6 6-6 6"/></svg>
      </button>
    </div>
  </section>

  <section class="kyank">
    <div class="kyank-left">
      <div class="ketter"></div>
      <svg class="yerekankyun" viewBox="0 0 454 410" width="454" height="410">
        <defs>
          <linearGradient id="gouyn" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#6400dc"/>
            <stop offset="1" stop-color="#7a2be0"/>
          </linearGradient>
        </defs>
        <polygon points="22,22 432,22 227,385" fill="url(#gouyn)" stroke="url(#gouyn)" stroke-width="44" stroke-linejoin="round"/>
      </svg>

      <div class="images">
        <img class="face face-man active" src="${man}" alt="">
        <img class="face face-woman" src="${woman}" alt="">
      </div>
    </div>

    <div class="kyank-right">
      <h2>Դարձիր Evocabank-ի հաճախորդ բիոմետրիկ նույնականացմամբ</h2>
      <p>Սկանավորիր QR կոդը, ներբեռնիր EvocaTOUCH հարմարավետ հավելվածը, ստեղծիր քո հաշիվը և ստացիր քարտ</p>
      <div class="kyank-row">
        <img class="qr" src="${qrImg}" alt="">
        <a href="#" class="button button-more">Իմանալ ավելին</a>
      </div>
    </div>
  </section>

  <section class="best">
    <h2 class="title">Լավագույնը Evocabank-ից</h2>
    <div class="cards">
      <div class="card">
        <span class="tag">Թվային քարտեր</span>
        <h3>Evoca Digital քարտ</h3>
        <p>Evoca Digital քարտն արդեն հասանելի է EvocaTOUCH հավելվածով: Ակտիվացրու այն հիմա և ընտրիր քո սիրելի դիզայնը:</p>
      </div>
      <div class="card">
        <span class="tag">Նվեր քարտեր</span>
        <h3>Evoca Gift Card</h3>
        <p>Գնիր Evoca Gift Card, և լավագույն նվերը կլինի քոնը: Քարտը հարմար է բոլոր առիթների համար:</p>
      </div>
      <div class="card">
        <span class="tag">Նոր հավելված</span>
        <h3>EvocaTOUCH 2</h3>
        <p>EvocaTOUCH-ը պարզապես բանկային հավելված չէ, վստահ ենք՝ այն քեզ համար դառնալու է ապրելակերպ:</p>
      </div>
      <div class="card">
        <span class="tag">Օնլայն վճարումներ</span>
        <h3>Արագ online վճարումներ</h3>
        <p>Կատարիր քո ընթացիկ վճարումները Evocabank-ի online տերմինալի միջոցով պարզ և արագ: Այն հասանելի է 24/7:</p>
      </div>
    </div>
  </section>

  <section class="qards">
    <div class="qardsImg">
      <img src="${card1}" alt="">
      <img src="${card2}" alt="">
      <img src="${card3}" alt="">
    </div>
    <img class="qardMain" src="${card}" alt="">
    <div class="cardsText">
      <h2 class="Classic">Arca Classic</h2>
      <p class="ClassicP">
        Ձեռք բեր ArCa Classic քարտը և կատարիր քո գործարքները մեր նորաոճ քարտի օգնությամբ:
        Ընդամենը մեկ հպում EvocaTOUCH հավելվածում և վերջ:
        Քարտը կարող ես ստանալ նույնիսկ առանց Բանկ այցելելու՝
        հավելվածում նշելով առաքման տարբերակը:
        Evocabank-ը մշտապես հոգում է քո հարմարավետության մասին:
      </p>
      <button class="button button-more">Մանրամասն</button>
    </div>
  </section>

  <section class="calc">
    <h2 class="calc-title">Հաշվիչներ</h2>
    <div class="tabs">
      <button class="tab active">Վարկ</button>
      <button class="tab">Ավանդ</button>
    </div>
    <div class="calc-box">
      <div class="calc-grid">
        <div>
          <div class="field">
            <span>Վարկի գումար</span>
            <input type="number" value="0">
          </div>
          <input type="range" class="range" min="0" max="50000000" value="0">
          <div class="minmax"><span>0</span><span>50000000</span></div>
        </div>
        <div>
          <div class="field">
            <span>Ժամկետ</span>
            <div class="field-right">
              <input type="number" value="1">
              <b>ամիս</b>
            </div>
          </div>
          <input type="range" class="range" min="1" max="1200" value="1">
          <div class="minmax"><span>1 ամիս</span><span>1200 ամիս</span></div>
        </div>
        <div>
          <div class="field">
            <span>Տարեկան տոկոսադրույք</span>
            <div class="field-right">
              <input type="number" value="1">
              <b>%</b>
            </div>
          </div>
          <input type="range" class="range" min="1" max="36" value="1">
          <div class="minmax"><span>1 %</span><span>36 %</span></div>
        </div>
        <div class="pay-type">
          <p>Մարման ձև</p>
          <div class="radios">
            <label><input type="radio" name="type" checked> Զսպանակաձև</label>
            <label><input type="radio" name="type"> Անուիտետ</label>
          </div>
        </div>
      </div>
      <div class="calc-bottom">
        <p>Բոլոր հաշվարկները կրում են մոտավոր բնույթ և չեն հանդիսանում հրապարակային առաջարկ:</p>
        <button class="button button-calc">Հաշվել</button>
      </div>
    </div>
  </section>

  <section class="mobile">
    <div class="laptop">
      <div class="laptop-screen">
        <img class="screenPng" src="${screenImg}" alt="">
      </div>
      <div class="laptop-base"></div>
    </div>
    <div class="phone">evoca</div>
    <div class="mobile-info">
      <h2>Օնլայն և մոբայլ բանկինգ</h2>
      <p>Evocabank-ը արագ, պարզ և նորարար ծառայություններ մատուցող բանկ է, որն առանձնանում է տեղեկատվական նորագույն տեխնոլոգիաների ակտիվ կիրառմամբ:</p>
      <div class="mobile-row">
        <img class="mobile-qr" src="${qrImg}" alt="">
        <div class="mobile-right">
          <span class="mobile-text">Ներբեռնել հավելվածները՝</span>
          <div class="stores">
            <a href="#" class="store">
              <svg width="20" height="24" viewBox="0 0 24 24" fill="#fff"><path d="M16.4 12.6c0-2.4 2-3.5 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.8-1.6 0-3.1 1-4 2.4-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.8 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8 1.4 0 1.9.8 3.2.8 1.3 0 2.1-1.2 2.9-2.3.9-1.3 1.3-2.6 1.3-2.7-.1 0-2.4-.9-2.4-3.6zM14 5.4c.7-.8 1.1-1.9 1-3-1 0-2.1.7-2.8 1.5-.6.7-1.1 1.8-1 2.9 1.1.1 2.2-.6 2.8-1.4z"/></svg>
              <div>
                <small>Download on the</small>
                <b>App Store</b>
              </div>
            </a>
            <a href="#" class="store">
              <svg width="22" height="24" viewBox="0 0 22 24"><path fill="#00d1ff" d="M1 1l11 11L1 23z"/><path fill="#00e676" d="M1 1l14 8-3 3z"/><path fill="#ff3d57" d="M1 23l14-8-3-3z"/><path fill="#ffc400" d="M15 9l5 3-5 3-3-3z"/></svg>
              <div>
                <small>GET IT ON</small>
                <b>Google Play</b>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="partners">
    <div class="partners-info">
      <h2>Գործընկերներ</h2>

      <p>
        Դարձի՛ր Evocabank-ի գործընկերն ու եկե՛ք միասին գնանք դեպի ավելի
        գրավիչ նոր իրականություն։ Դառնալով Evoca ընտանիքի անդամ՝ Դուք
        մուտք կգործեք ժամանակակից և արդյունավետ աշխարհի։ Մենք մշտապես բաց
        ենք հետաքրքիր առաջարկների ու համագործակցությունների համար։
      </p>

      <a href="#" class="button button-more">
        Բոլոր գործընկերները ❯
      </a>
    </div>

    <div class="partners-slider">
      <button class="partners-arrow" id="partnersPrev">❮</button>

      <div class="partners-track" id="partnersTrack">
        <div class="partner-logo">Telcell</div>
        <div class="partner-logo">CHiP STORE</div>
        <div class="partner-logo">IMR</div>
        <div class="partner-logo">Evoca</div>
        <div class="partner-logo">Telcell</div>
      </div>

      <button class="partners-arrow" id="partnersNext">❯</button>
    </div>
  </section>

  <section class="news">
    <div class="news-head">
      <h2>Վերջին նորությունները</h2>
      <a href="#" class="button button-news">Բոլոր նորությունները ❯</a>
    </div>
    <div class="news-list">
      ${newsCards}
    </div>
  </section>

  <section class="rates">
    <div class="rates-left">
      <p class="rates-note">20,000 ԱՄՆ դոլարից ավել կամ դրան համարժեք այլ արտարժույթի փոխարկման դեպքում գործարքը հաստատվում է Բանկի հայեցողությամբ և Բանկի կողմից որոշված փոխարժեքով։ 100,000 դրամ կամ դրան համարժեք արտարժույթից ավելի փոխանակական գործարքների իրականացման համար անհրաժեշտ է ներկայացնել անձը հաստատող փաստաթուղթ։</p>
      <div class="rates-tabs" id="ratesTabs">
        <button class="rates-tab active" data-tab="cash">Կանխիկ</button>
        <button class="rates-tab" data-tab="noncash">Անկանխիկ</button>
        <button class="rates-tab" data-tab="gold">Ոսկու փոխարժեք</button>
        <button class="rates-tab" data-tab="rub">Ռուբլու կանխիկ մուտք</button>
      </div>
      <div class="rates-box">
        <div class="rates-table">
          <div class="rates-row rates-row-head">
            <span></span><span>Առք</span><span>Վաճառք</span>
          </div>
          <div id="ratesBody"></div>
          <div class="rates-foot">
            <span class="rates-date">Թարմացվել է՝ 21.11.26</span>
            <a href="#" class="rates-more">Այլ արժույթներ</a>
          </div>
        </div>
        <div class="converter">
          <label class="conv-label">Ունեմ</label>
          <div class="conv-field">
            <input type="number" id="convFrom" min="0">
            <select id="convFromCur">
              <option value="AMD">AMD</option>
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="RUB">RUB</option>
            </select>
          </div>
          <label class="conv-label">Կստանամ</label>
          <div class="conv-field">
            <input type="number" id="convTo" min="0">
            <select id="convToCur">
              <option value="AMD">AMD</option>
              <option value="USD" selected>USD</option>
              <option value="EUR">EUR</option>
              <option value="RUB">RUB</option>
            </select>
          </div>
        </div>
      </div>
    </div>

    <aside class="rates-right">
      <h3>Մեր հասցեները</h3>
      <p>Բանկի հասցեները, աշխատաժամերը, բանկոմատները</p>
      <div class="map-card">
        <svg viewBox="0 0 280 190" width="280" height="190">
          <rect x="8" y="14" width="264" height="150" rx="6" fill="#f3f3f5"/>
          <path d="M8 70 L120 55 L120 150 L8 160Z" fill="#ebebee"/>
          <path d="M150 20 C170 70 200 60 215 110 S250 140 262 150" fill="none" stroke="#d8c8f5" stroke-width="3"/>
          <path d="M60 14 L90 164 M180 14 L160 164 M8 100 L272 90" stroke="#fff" stroke-width="3" fill="none"/>
          <text x="190" y="60" font-size="10" fill="#aaa">Yerevan</text>
          <path d="M90 78 a38 38 0 0 1 76 0 c0 28 -38 62 -38 62 s-38 -34 -38 -62z" fill="#6a0dd9"/>
          <path d="M111 66 l17 28 l17 -28 h-9 l-8 14 l-8 -14z" fill="#fff"/>
        </svg>
      </div>
      <a href="#" class="button button-map">Դիտել քարտեզը &nbsp;❯</a>
    </aside>
  </section>

  <section class="reviews">
    <svg class="rv-deco rv-zig-left" width="50" height="54" viewBox="0 0 50 54" fill="none" stroke="#a45be8" stroke-width="5"><path d="M4 4l14 10-10 8 20 8-8 10 20 8"/></svg>
    <svg class="rv-deco rv-zig-right" width="72" height="26" viewBox="0 0 72 26" fill="none" stroke="#ff1fd0" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6l12 12 10-10 12 12 10-10 12 10 8-6"/></svg>
    <svg class="rv-deco rv-quote-left" width="30" height="22" viewBox="0 0 30 22" fill="#6a0dd9"><path d="M0 0h13v13c0 5-3 8-8 9v-5c2-1 3-2 3-4H0zM17 0h13v13c0 5-3 8-8 9v-5c2-1 3-2 3-4h-8z"/></svg>
    <svg class="rv-deco rv-quote-right" width="30" height="22" viewBox="0 0 30 22" fill="#6a0dd9" style="transform:rotate(180deg)"><path d="M0 0h13v13c0 5-3 8-8 9v-5c2-1 3-2 3-4H0zM17 0h13v13c0 5-3 8-8 9v-5c2-1 3-2 3-4h-8z"/></svg>

    <div class="rv-content" id="rvContent">
      <div class="rv-stars" id="rvStars"></div>
      <p class="rv-text" id="rvText"></p>
      <h4 class="rv-name" id="rvName"></h4>
      <span class="rv-role" id="rvRole"></span>
    </div>
    <div class="rv-dots" id="rvDots"></div>
  </section>
  <div class="updated-bar">Թարմացվել է՝ 20/11/2026 11:39</div>

  <footer class="footer">
    <div class="footer-main">
      <div class="footer-brand">
        <a href="#" class="footer-logo">e<span>v</span>oca<em>BANK</em></a>
        <p class="footer-addr">ք. Երևան, 0010,<br>Հանրապետության 44/2</p>
        <p class="footer-reg">Evocabank-ը վերահսկվում է Հայաստանի Հանրապետության Կենտրոնական բանկի կողմից</p>
        <p class="footer-copy">1990 - 2026, © ԲՈԼՈՐ ԻՐԱՎՈՒՆՔՆԵՐԸ ՊԱՇՏՊԱՆՎԱԾ ԵՆ</p>
      </div>

      <div class="footer-col">
        <h4>Բանկի մասին</h4>
        <a href="#">Մեր մասին</a>
        <a href="#">Ղեկավարություն</a>
        <a href="#">Բաժնետերեր</a>
        <a href="#">Հաշվետվություններ</a>
        <a href="#">Իրավական ակտեր</a>
        <a href="#">Սակագներ</a>
        <a href="#">Օտարվող գույք</a>
        <a href="#">Կառուցապատողներ</a>
        <a href="#">Գործընկեր ավտոսրահներ</a>
        <a href="#">Սակագների արխիվ</a>
      </div>

      <div class="footer-col">
        <h4>Օգտակար հղումներ</h4>
        <a href="#">Հաճախորդի իրավունքները (Բողոքի ներկայացման կանոններ)</a>
        <a href="#">Հաճախորդի ռեզիդենտության չափանիշներ</a>
        <a href="#">Կարգավորում</a>
        <a href="#">Գաղտնիության քաղաքականություն</a>
        <a href="#">ՖԻՆ. հաշտարար</a>
        <a href="#">Ֆինանսական հանցագործությունների կանխարգելում</a>
        <a href="#">Դիմումներ Բանկի քարտապանների համար</a>
      </div>

      <div class="footer-col">
        <h4>Այլ հղումներ</h4>
        <a href="#">EvocaONLINE</a>
        <a href="#">Պահատուփեր</a>
        <a href="#">Հաճախ տրվող հարցեր</a>
        <a href="#">Հայտարարություններ</a>
        <a href="#">Dibrary</a>
        <a href="#">Բուլետեններ</a>
        <a href="#">Հետադարձ կապ</a>
        <a href="#">Կայքի քարտեզ</a>
      </div>

      <div class="footer-contact">
        <div class="socials">
          <a href="#" aria-label="Facebook"><svg width="16" height="22" viewBox="0 0 16 24" fill="#c9c9ce"><path d="M10 24V13h4l.6-4.5H10V6.2c0-1.3.4-2.2 2.200-2.200H15V.2C14.600.1 13.200 0 11.600 0 8.200 0 5.900 2.100 5.900 5.800v3.200H2V13.500h3.900V24z"/></svg></a>
          <a href="#" aria-label="Instagram"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#c9c9ce" stroke-width="2.500"><rect x="2" y="2" width="20" height="20" rx="6"/><circle cx="12" cy="12" r="4.500"/><circle cx="17.500" cy="6.500" r="1" fill="#c9c9ce"/></svg></a>
          <a href="#" aria-label="YouTube"><svg width="26" height="20" viewBox="0 0 26 20"><rect width="26" height="20" rx="6" fill="#c9c9ce"/><path d="M10 5.500l7 4.500-7 4.500z" fill="#fff"/></svg></a>
          <a href="#" aria-label="LinkedIn"><svg width="22" height="22" viewBox="0 0 24 24" fill="#c9c9ce"><rect x="2" y="9" width="4.500" height="13"/><circle cx="4.250" cy="4.500" r="2.500"/><path d="M9.500 9h4.300v1.800c.6-1.200 2.100-2.100 4-2.100 4 0 4.700 2.600 4.700 6V22H18v-6.300c0-1.500 0-3.200-2-3.200s-2.300 1.500-2.300 3.100V22H9.500z"/></svg></a>
        </div>
        <div class="footer-stores">
          <a href="#" class="store">
            <svg width="16" height="20" viewBox="0 0 24 24" fill="#fff"><path d="M16.4 12.6c0-2.400 2-3.500 2.100-3.600-1.100-1.700-2.900-1.900-3.500-1.900-1.500-.2-2.900.9-3.700.9-.8 0-1.900-.9-3.200-.8-1.600 0-3.100 1-4 2.400-1.700 3-.4 7.400 1.200 9.800.8 1.200 1.800 2.500 3 2.400 1.200 0 1.700-.8 3.100-.8 1.400 0 1.900.8 3.200.8 1.300 0 2.100-1.200 2.900-2.300.9-1.300 1.300-2.600 1.300-2.700-.1 0-2.400-.9-2.400-3.600zM14 5.400c.7-.8 1.100-1.900 1-3-1 0-2.100.7-2.800 1.500-.6.7-1.100 1.800-1 2.900 1.100.1 2.200-.6 2.800-1.400z"/></svg>
            <div><small>Download on the</small><b>App Store</b></div>
          </a>
          <a href="#" class="store">
            <svg width="18" height="20" viewBox="0 0 22 24"><path fill="#00d1ff" d="M1 1l11 11L1 23z"/><path fill="#00e676" d="M1 1l14 8-3 3z"/><path fill="#ff3d57" d="M1 23l14-8-3-3z"/><path fill="#ffc400" d="M15 9l5 3-5 3-3-3z"/></svg>
            <div><small>GET IT ON</small><b>Google Play</b></div>
          </a>
        </div>
        <a href="#" class="footer-link">Բանկի հասցեները և աշխատաժամերը</a>
        <a href="#" class="footer-link">Կապ մեզ հետ</a>
        <a href="#" class="footer-link">+374 10 605555</a>
        <a href="#" class="footer-link">8444</a>
      </div>
    </div>

    <div class="footer-bottom">
      <p>Հարգելի՛ այցելու, Կայքի որևէ տեղեկատվության վերաբերյալ տարբեր թեզումներ անհամապատասխանության դեպքում առաջնորդվեք ընդհանուր օրենսդրությամբ։ Կայքում տեղադրված տեղեկատվությունը ունի տեղեկատվական բնույթ և չի հանդիսանում հրապարակային առաջարկ։</p>
      <div class="footer-partners">
        <span class="fp-logo">fininfo</span>
        <span class="fp-logo">abcfinance.am</span>
        <span class="fp-logo fp-arca">arca</span>
        <span class="fp-logo fp-aa">ACRA</span>
      </div>
    </div>
  </footer>

  <a href="#" class="call">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="#6a0dd9"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11 11 0 0 0 3.6.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.6 3.6a1 1 0 0 1-.25 1z"/></svg>
  </a>
  <a href="#" class="chat">Գրեք մեզ, մենք օնլայն ենք !<span class="xosq-ket"></span></a>
`;

// ՍԼԱՅԴԵՐԻ ՏՐԱՄԱԲԱՆՈՒԹՅՈՒՆ

const heroSection = document.getElementById("heroSection");
const heroTitle = document.getElementById("heroTitle");
const heroDesc = document.getElementById("heroDesc");
const dotsContainer = document.getElementById("dotsContainer");

let isAnimating = false;

// Ստեղծում ենք dots-երը
slidesData.forEach((_, index) => {
  const dot = document.createElement("span");
  dot.classList.add("dot");

  if (index === 0) {
    dot.classList.add("active");
  }

  dot.onclick = () => {
    if (isAnimating || index === current) return;

    const direction = index > current ? 1 : -1;
    current = index;
    updateSlide(direction);
  };

  dotsContainer.appendChild(dot);
});

const dots = dotsContainer.querySelectorAll(".dot");

function updateSlide(direction = 1, firstSlide = false) {
  const slide = slidesData[current];

  heroTitle.textContent = slide.title;
  heroDesc.textContent = slide.desc;
  heroSection.style.backgroundColor = slide.bg;

  if (
    slide.bg === "#222022" ||
    slide.bg === "#111011" ||
    slide.bg === "#7a4cb8"
  ) {
    heroSection.style.color = "#fff";
  } else {
    heroSection.style.color = "#333";
  }

  dots.forEach((dot, index) => {
    dot.classList.toggle("active", index === current);
  });

  const oldImg = document.getElementById("heroImg");

  if (firstSlide) {
    oldImg.src = slide.img;
    return;
  }

  isAnimating = true;

  const newImg = document.createElement("img");
  newImg.src = slide.img;
  newImg.alt = "";
  newImg.className = "hero-img";

  newImg.style.transition = "transform 0.7s ease, opacity 0.7s ease";
  newImg.style.opacity = "0";
  newImg.style.transform =
    direction === 1 ? "translateX(110%)" : "translateX(-110%)";
  newImg.style.zIndex = "2";

  oldImg.style.transition = "transform 0.7s ease, opacity 0.7s ease";
  oldImg.style.opacity = "1";
  oldImg.style.transform = "translateX(0)";
  oldImg.style.zIndex = "1";

  heroSection.appendChild(newImg);

  const startAnimation = () => {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        oldImg.style.transform =
          direction === 1 ? "translateX(-110%)" : "translateX(110%)";

        oldImg.style.opacity = "0";

        newImg.style.transform = "translateX(0)";
        newImg.style.opacity = "1";
      });
    });

    setTimeout(() => {
      oldImg.remove();

      newImg.id = "heroImg";
      newImg.style.zIndex = "";
      newImg.style.transition = "";
      newImg.style.transform = "";
      newImg.style.opacity = "";

      isAnimating = false;
    }, 750);
  };

  if (newImg.complete) {
    startAnimation();
  } else {
    newImg.onload = startAnimation;

    newImg.onerror = () => {
      newImg.remove();
      isAnimating = false;
    };
  }
}

// Ձախ կոճակ
document.getElementById("prev").onclick = () => {
  if (isAnimating) return;

  current = (current - 1 + slidesData.length) % slidesData.length;
  updateSlide(-1);
};

// Աջ կոճակ
document.getElementById("next").onclick = () => {
  if (isAnimating) return;

  current = (current + 1) % slidesData.length;
  updateSlide(1);
};

// Առաջին սլայդը
updateSlide(1, true);

// Դեմքերի սահուն փոփոխության անիմացիա
const faceMan = document.querySelector(".face-man");
const faceWoman = document.querySelector(".face-woman");

let isMan = true;

setInterval(() => {
  if (isMan) {
    faceMan.classList.remove("active");
    faceWoman.classList.add("active");
  } else {
    faceWoman.classList.remove("active");
    faceMan.classList.add("active");
  }

  isMan = !isMan;
}, 3000);

// Գործընկերների սլայդեր
const partnersTrack = document.getElementById("partnersTrack");
const partnersNext = document.getElementById("partnersNext");
const partnersPrev = document.getElementById("partnersPrev");

let partnersPosition = 0;

partnersNext.onclick = () => {
  partnersPosition -= 220;

  if (partnersPosition < -440) {
    partnersPosition = 0;
  }

  partnersTrack.style.transform = `translateX(${partnersPosition}px)`;
};

partnersPrev.onclick = () => {
  partnersPosition += 220;

  if (partnersPosition > 0) {
    partnersPosition = -440;
  }

  partnersTrack.style.transform = `translateX(${partnersPosition}px)`;
};

// Փոխարժեքներ
const flagSvg = {
  USD: '<svg width="24" height="24" viewBox="0 0 24 24"><defs><clipPath id="fu"><circle cx="12" cy="12" r="12"/></clipPath></defs><g clip-path="url(#fu)"><rect width="24" height="24" fill="#fff"/><g fill="#d33"><rect y="0" width="24" height="3"/><rect y="6" width="24" height="3"/><rect y="12" width="24" height="3"/><rect y="18" width="24" height="3"/></g><rect width="12" height="12" fill="#2a3f8f"/></g></svg>',
  EUR: '<svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#1c3a9a"/><g fill="#fc0"><circle cx="12" cy="5" r="1.1"/><circle cx="12" cy="19" r="1.1"/><circle cx="5" cy="12" r="1.1"/><circle cx="19" cy="12" r="1.1"/><circle cx="7" cy="7" r="1.1"/><circle cx="17" cy="7" r="1.1"/><circle cx="7" cy="17" r="1.1"/><circle cx="17" cy="17" r="1.1"/></g></svg>',
  RUB: '<svg width="24" height="24" viewBox="0 0 24 24"><defs><clipPath id="fr"><circle cx="12" cy="12" r="12"/></clipPath></defs><g clip-path="url(#fr)"><rect width="24" height="8" fill="#fff"/><rect y="8" width="24" height="8" fill="#2a4ea6"/><rect y="16" width="24" height="8" fill="#d33"/></g><circle cx="12" cy="12" r="11.5" fill="none" stroke="#e5e5ea"/></svg>',
  GOLD: '<svg width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#f2c94c"/><text x="12" y="16" text-anchor="middle" font-size="11" font-weight="700" fill="#fff">Au</text></svg>',
};

const ratesData = {
  cash: [
    { cur: "USD", buy: 358, sell: 362 },
    { cur: "EUR", buy: 390, sell: 401 },
    { cur: "RUB", buy: 4.25, sell: 4.43 },
  ],
  noncash: [
    { cur: "USD", buy: 359, sell: 361 },
    { cur: "EUR", buy: 391, sell: 399 },
    { cur: "RUB", buy: 4.3, sell: 4.4 },
  ],
  gold: [{ cur: "GOLD", label: "Ոսկի 1 գ", buy: 28500, sell: 30500 }],
  rub: [{ cur: "RUB", buy: 4.2, sell: 4.5 }],
};

const ratesBody = document.getElementById("ratesBody");

function renderRates(tab) {
  ratesBody.innerHTML = ratesData[tab]
    .map(
      (r) => `
      <div class="rates-row">
        <span class="rates-cur">${flagSvg[r.cur]}<b>${r.label || r.cur}</b></span>
        <span class="rates-val"><i class="arr down"></i>${r.buy}</span>
        <span class="rates-val"><i class="arr up"></i>${r.sell}</span>
      </div>`
    )
    .join("");
}

document.querySelectorAll(".rates-tab").forEach((btn) => {
  btn.onclick = () => {
    document.querySelectorAll(".rates-tab").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    renderRates(btn.dataset.tab);
  };
});

renderRates("cash");

// Կոնվերտոր (օգտագործում է կանխիկ փոխարժեքները)
const convFrom = document.getElementById("convFrom");
const convTo = document.getElementById("convTo");
const convFromCur = document.getElementById("convFromCur");
const convToCur = document.getElementById("convToCur");

function toAmd(amount, cur) {
  if (cur === "AMD") return amount;
  const r = ratesData.cash.find((x) => x.cur === cur);
  return amount * r.buy;
}

function fromAmd(amount, cur) {
  if (cur === "AMD") return amount;
  const r = ratesData.cash.find((x) => x.cur === cur);
  return amount / r.sell;
}

function convert() {
  const value = parseFloat(convFrom.value);
  if (isNaN(value)) {
    convTo.value = "";
    return;
  }
  const result = fromAmd(toAmd(value, convFromCur.value), convToCur.value);
  convTo.value = Math.round(result * 100) / 100;
}

convFrom.oninput = convert;
convFromCur.onchange = convert;
convToCur.onchange = convert;

// Կարծիքներ
const reviewsData = [
  { text: "Evocabank-ի ծառայությունները արագ են և հարմար, EvocaTOUCH հավելվածը իսկապես ապրելակերպ է:", name: "Աննա Սարգսյան", role: "Հաճախորդ" },
  { text: "Քարտը ստացա առանց բանկ այցելելու, ամեն ինչ արվեց հավելվածի միջոցով մի քանի րոպեում:", name: "Դավիթ Գրիգորյան", role: "Հաճախորդ" },
  { text: "Աշխատակիցները միշտ պատրաստակամ են և օգնում են լուծել ցանկացած հարց:", name: "Մարիամ Հակոբյան", role: "Հաճախորդ" },
  { text: "Լավագույն նորարարական և թվային բանկ՝ լավագույն ծառայություններով և անձնակազմով:", name: "Էլեն Վարդանյան", role: "Հաճախորդ" },
  { text: "Ավանդի բարձր տոկոսները և օնլայն բանկինգի հարմարավետությունը ինձ համոզեցին ընտրել Evoca-ն:", name: "Արման Պետրոսյան", role: "Հաճախորդ" },
];

const rvContent = document.getElementById("rvContent");
const rvStars = document.getElementById("rvStars");
const rvText = document.getElementById("rvText");
const rvName = document.getElementById("rvName");
const rvRole = document.getElementById("rvRole");
const rvDots = document.getElementById("rvDots");

const starSvg = '<svg width="34" height="34" viewBox="0 0 24 24" fill="#f7d002"><path d="M12 1.5l3 7.3 7.9.6-6 5.2 1.9 7.7L12 18.1 5.2 22.3l1.9-7.7-6-5.2 7.9-.6z"/></svg>';
rvStars.innerHTML = starSvg.repeat(5);

let reviewIndex = 0;
let reviewTimer;

function showReview(i) {
  reviewIndex = i;
  rvContent.classList.add("fade");
  setTimeout(() => {
    const r = reviewsData[i];
    rvText.textContent = r.text;
    rvName.textContent = r.name;
    rvRole.textContent = r.role;
    rvContent.classList.remove("fade");
  }, 250);
  rvDots.querySelectorAll(".rv-dot").forEach((d, idx) => d.classList.toggle("active", idx === i));
}

function startReviewTimer() {
  clearInterval(reviewTimer);
  reviewTimer = setInterval(() => showReview((reviewIndex + 1) % reviewsData.length), 5000);
}

reviewsData.forEach((_, i) => {
  const d = document.createElement("span");
  d.className = "rv-dot" + (i === 0 ? " active" : "");
  d.onclick = () => {
    showReview(i);
    startReviewTimer();
  };
  rvDots.appendChild(d);
});

const first = reviewsData[0];
rvText.textContent = first.text;
rvName.textContent = first.name;
rvRole.textContent = first.role;
startReviewTimer();
